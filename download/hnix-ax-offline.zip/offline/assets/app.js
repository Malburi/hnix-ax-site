(function () {
  var body = document.body;
  var toggle = document.querySelector('.sidebar-toggle');
  if (toggle) toggle.addEventListener('click', function () { body.classList.toggle('close'); });
  // 좁은 화면에서 목차 항목을 고르면 목차를 닫는다
  document.querySelectorAll('.sidebar-nav a').forEach(function (a) {
    a.addEventListener('click', function () { if (window.innerWidth <= 860) body.classList.remove('close'); });
  });

  // 코드 복사
  document.querySelectorAll('.markdown-section pre:not(.mermaid)').forEach(function (pre) {
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'docsify-copy-code-button';
    btn.textContent = '복사';
    btn.addEventListener('click', function () {
      var text = pre.querySelector('code') ? pre.querySelector('code').innerText : pre.innerText;
      var done = function (ok) { btn.textContent = ok ? '복사됨' : '실패'; setTimeout(function () { btn.textContent = '복사'; }, 1500); };
      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(function () { done(true); }, function () { done(fallback(text)); });
      } else { done(fallback(text)); }
    });
    pre.appendChild(btn);
  });
  function fallback(text) {
    var ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    var ok = false; try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    document.body.removeChild(ta); return ok;
  }

  // 검색 — 미리 만든 색인(search-index.js)에서 찾는다
  var q = document.getElementById('q');
  var panel = document.getElementById('results');
  var index = window.HNIX_SEARCH || [];
  var root = window.HNIX_ROOT || '';
  function escape(s) { return s.replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function mark(s, word) {
    var i = s.toLowerCase().indexOf(word.toLowerCase());
    if (i < 0) return escape(s);
    return escape(s.slice(0, i)) + '<em class="search-keyword">' + escape(s.slice(i, i + word.length)) + '</em>' + escape(s.slice(i + word.length));
  }
  if (q && panel) q.addEventListener('input', function () {
    var word = q.value.trim();
    if (!word) { panel.classList.remove('show'); panel.innerHTML = ''; return; }
    var lower = word.toLowerCase();
    var hits = [];
    index.forEach(function (p) {
      var inTitle = p.title.toLowerCase().indexOf(lower) >= 0;
      var at = p.text.toLowerCase().indexOf(lower);
      if (!inTitle && at < 0) return;
      var start = Math.max(0, at - 30);
      var snippet = at < 0 ? p.text.slice(0, 80) : (start > 0 ? '…' : '') + p.text.slice(start, at + word.length + 50) + '…';
      hits.push({ p: p, score: inTitle ? 0 : 1, snippet: snippet });
    });
    hits.sort(function (a, b) { return a.score - b.score; });
    panel.innerHTML = hits.length
      ? hits.slice(0, 20).map(function (h) { return '<div class="matching-post"><a href="' + root + h.p.url + '"><h2>' + mark(h.p.title, word) + '</h2><p>' + mark(h.snippet, word) + '</p></a></div>'; }).join('')
      : '<div class="matching-post"><p>검색 결과가 없습니다.</p></div>';
    panel.classList.add('show');
  });
})();
